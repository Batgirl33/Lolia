-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jan 23, 2023 at 05:33 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lolia1`
--

-- --------------------------------------------------------

--
-- Table structure for table `address table`
--

CREATE TABLE `address table` (
  `adress_id` int(11) NOT NULL,
  `city` varchar(45) NOT NULL,
  `postal_code` int(11) NOT NULL,
  `st_name` varchar(45) NOT NULL,
  `custmer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `address table`
--

INSERT INTO `address table` (`adress_id`, `city`, `postal_code`, `st_name`, `custmer_id`) VALUES
(1, 'Dammam', 2000, 'Al-jazerah', 124),
(2, 'Dammam', 2001, 'Al-sa\'aeed', 125),
(3, 'Alkhobar', 2002, 'Ahmed bin ali st', 126),
(4, 'Dahran', 2003, 'Ali bin taleb st', 127),
(5, 'Alkhobar', 2004, 'Habeb bin medaher st', 128),
(6, 'Dammam', 2004, '5A st', 129),
(7, 'Qatif', 2005, 'AlHkuel st', 130),
(8, 'Qatif', 2006, 'AlAbass bin Ali st', 131),
(9, 'Jeddah', 2007, 'Alsadfah st ', 132),
(10, 'Makah', 2008, 'Alsalam st', 133),
(11, 'Tabuk', 2009, 'AlLozah st', 134);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_role` varchar(45) NOT NULL,
  `admin_name` varchar(45) NOT NULL,
  `website_url` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_role`, `admin_name`, `website_url`) VALUES
(20, 'Manger', 'Noor Ali', 'www.https'),
(21, 'Supervisor', 'Batool Jaffar', 'www.https');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(45) NOT NULL,
  `customer_contact` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `customer_contact`) VALUES
(1, 'Zahraa Ali', '0597731221'),
(2, 'Azhar Jaffar', '0544007327'),
(3, 'Safa\'a Mohammed', '0568824433'),
(4, 'Haleemah Ahmad', '0542036559'),
(5, 'Mosa Ali', '0695556666'),
(6, 'Jassim Habeb', '0563342288'),
(7, 'Ghaith Ali', '0545563300'),
(8, 'Sara Ali', '0568889999'),
(9, 'Narjes Nasser', '0546677882'),
(10, 'Amal Ali', '0563344221');

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `loan_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `duration` date NOT NULL,
  `amount` double NOT NULL,
  `invoive_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`loan_id`, `admin_id`, `customer_id`, `duration`, `amount`, `invoive_id`) VALUES
(100, 20, 1, '2023-01-01', 3000, 1),
(101, 21, 4, '2023-01-10', 1100, 3);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `order_no` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `order_amount` int(11) NOT NULL,
  `custmer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`order_no`, `order_date`, `order_amount`, `custmer_id`) VALUES
(300, '2023-01-24', 2000, 6),
(301, '2022-05-25', 5610, 7),
(302, '2022-07-12', 1000, 3),
(303, '2023-01-26', 3300, 2),
(304, '2022-09-12', 6600, 5),
(305, '2019-08-01', 1200, 9),
(306, '2023-01-08', 4000, 10),
(307, '2023-01-17', 8000, 1),
(308, '2023-01-17', 4200, 6),
(309, '2022-12-26', 5630, 4);

-- --------------------------------------------------------

--
-- Table structure for table `order_product`
--

CREATE TABLE `order_product` (
  `order_no` int(11) NOT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_product`
--

INSERT INTO `order_product` (`order_no`, `order_id`) VALUES
(300, 10),
(301, 11),
(302, 12),
(303, 13),
(304, 14),
(305, 15),
(306, 16),
(307, 17),
(308, 18),
(309, 19);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `payment_statue` varchar(45) NOT NULL,
  `payment_method` varchar(45) NOT NULL,
  `payment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `customer_id`, `payment_statue`, `payment_method`, `payment_date`) VALUES
(401, 1, 'Compelete', 'mada', '2023-01-17'),
(402, 10, 'In process', 'Stc_pay', '2023-01-08'),
(403, 4, 'loan', 'mada', '2022-12-26'),
(404, 3, 'Compelete', 'Check', '2022-07-12'),
(405, 7, 'In process', 'Apple_pay', '2022-05-25'),
(406, 9, 'Compelete', 'Cache', '2019-08-01'),
(407, 2, 'loan', 'visa', '2023-01-26'),
(408, 5, 'In process', 'mada', '2022-09-12');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `quantity` varchar(45) NOT NULL,
  `Availability` char(45) NOT NULL,
  `supplire_id` int(11) NOT NULL,
  `product_price` double NOT NULL,
  `product_name` varchar(45) NOT NULL,
  `product_pic` int(11) DEFAULT NULL,
  `product_descreption` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `quantity`, `Availability`, `supplire_id`, `product_price`, `product_name`, `product_pic`, `product_descreption`) VALUES
(1, '5', 'In stock', 0, 800, 'Daimond Earring', NULL, ''),
(2, '3', 'In stock', 0, 200, 'Victoria Ring', NULL, ''),
(3, '3', 'out-of-stock', 1, 300, 'Heart Earring', NULL, ''),
(4, '6', 'out-of-stock', 2, 350, 'Moon Earring', NULL, ''),
(5, '8', 'In stock', 3, 600, 'amazing ring', NULL, ''),
(6, '9', 'In stock', 1, 450, 'Heart ring', NULL, ''),
(7, '4', 'out-of-stock', 2, 1000, 'Gold Bracelet', NULL, ''),
(8, '1', 'In stock', 3, 550, ' Monica Bracelet', NULL, ''),
(9, '2', 'In stock', 0, 600, 'Beauty Bracelet', NULL, ''),
(10, '1', 'In stock', 3, 1200, 'Gold Necklace ', NULL, ''),
(11, '2', 'out-of-stock', 1, 500, 'Beauty Necklace', NULL, ''),
(12, '6', 'out-of-stock', 2, 1100, 'Wide Gold Necklace ', NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supplire_id` int(11) NOT NULL,
  `supplire_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplire_id`, `supplire_name`) VALUES
(1, 'Noor Alsadah'),
(2, 'Kareemah Alsaffar'),
(3, 'Mosa Alshaikh');

-- --------------------------------------------------------

--
-- Table structure for table `trackingloliy`
--

CREATE TABLE `trackingloliy` (
  `tracking_no` int(11) NOT NULL,
  `carrier_name` varchar(45) NOT NULL,
  `order_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trackingloliy`
--

INSERT INTO `trackingloliy` (`tracking_no`, `carrier_name`, `order_no`) VALUES
(1, 'Samsma', 300),
(2, 'Naqel', 302),
(3, 'Samsma', 303),
(4, 'Usp', 307),
(5, 'Noon', 301),
(6, 'Aramx', 304),
(7, 'Aramx', 305),
(8, 'Naqel', 306);

-- --------------------------------------------------------

--
-- Table structure for table `trolly`
--

CREATE TABLE `trolly` (
  `TROLLY_ID` int(11) NOT NULL,
  `CID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trolly`
--

INSERT INTO `trolly` (`TROLLY_ID`, `CID`) VALUES
(501, 1),
(502, 2),
(503, 3),
(504, 4),
(505, 5),
(506, 6),
(507, 7),
(508, 9),
(509, 10);

-- --------------------------------------------------------

--
-- Table structure for table `trolly_product`
--

CREATE TABLE `trolly_product` (
  `TROLLY_ID` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trolly_product`
--

INSERT INTO `trolly_product` (`TROLLY_ID`, `product_id`) VALUES
(501, 7),
(501, 1),
(502, 2),
(503, 3),
(504, 4),
(506, 5),
(507, 6),
(508, 7),
(509, 8),
(505, 9);

-- --------------------------------------------------------

--
-- Table structure for table `website`
--

CREATE TABLE `website` (
  `website_url` varchar(100) NOT NULL,
  `website_name` varchar(45) NOT NULL,
  `contact_no` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `website`
--

INSERT INTO `website` (`website_url`, `website_name`, `contact_no`) VALUES
('www.lolia.com', 'Lolia', '0568884444');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address table`
--
ALTER TABLE `address table`
  ADD PRIMARY KEY (`adress_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
  ADD PRIMARY KEY (`loan_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_no`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplire_id`);

--
-- Indexes for table `trackingloliy`
--
ALTER TABLE `trackingloliy`
  ADD PRIMARY KEY (`tracking_no`);

--
-- Indexes for table `trolly`
--
ALTER TABLE `trolly`
  ADD PRIMARY KEY (`TROLLY_ID`);

--
-- Indexes for table `trolly_product`
--
ALTER TABLE `trolly_product`
  ADD KEY `product_id` (`product_id`),
  ADD KEY `trolly_product_ibfk_1` (`TROLLY_ID`);

--
-- Indexes for table `website`
--
ALTER TABLE `website`
  ADD PRIMARY KEY (`website_url`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `trolly_product`
--
ALTER TABLE `trolly_product`
  ADD CONSTRAINT `trolly_product_ibfk_1` FOREIGN KEY (`TROLLY_ID`) REFERENCES `trolly` (`TROLLY_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `trolly_product_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
