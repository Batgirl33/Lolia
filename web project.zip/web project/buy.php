  <?php include('datab.php'); ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>

    <title> Buy Products </title>
     <link rel="stylesheet" type="text/css" href="style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
      <!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
   </head>
   
    <body>
        <header>
             <h1>Lolia Jewelry</h1>
           <ul style="text-align: top">
               <?php 
               if(!isset($_SESSION['Email'])){
                   ?> 
                   <li> <a href="login.php" class="button">Login</a></li>
                <li><a href="reg.php" class="button">Register </a></li>
                   <?php
               }else{
                  $sql = "SELECT * FROM customer WHERE Email='".$_SESSION['Email']."'";
                  $r = $db_link->query($sql);
                   $row = mysqli_fetch_assoc($r);
                   echo $row['customer_name'];
               }
               ?>

                <li><a href="cart.php"><img src="shopping-cart.png" alt="Shopping cart" width="20" height="20"/> </a></li>
                <?php 
                  if(isset($_SESSION['Email'])){
                      ?>
                      <li> <a href="logout.php" class="button" class="log">Logout</a></li>
                      <?php
                  }
                ?>
               


            
            
              </ul> 
            <nav>
            <ul style="text-align: center">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="#prodect">Prodects categories</a></li>
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
            </nav>
        </header>
        
         
                    <!-- body section starts  -->
    
        <br><br><br><br><br>
            
            <h2 style="margin-left: 500px;">Your bought product</h2><br>
      
  <table width="90%" border="1px" style="border-collapse: collapse; margin-left: 55px;">
           <thead>
             <tr>
               <th>#</th>
               <th>Title</th>
               <th>Qty</th>
               <th>color</th>
               <th>size</th>
               <th>price</th>
               <th>Total price</th>
              


             </tr>
           </thead>
           <tbody>
             <tr>
               <?php
                    if(!empty($_COOKIE['order'])){
                        $total = 0;
                        $i=0;
                        $order  = json_decode($_COOKIE['order'],true);
                      
                        foreach($order as $keys => $values){
                          $i++;
                    ?>
                        <tr align="center">
                          <td><?php echo $i; ?></td>
                        <td><?php echo $values["title"]; ?></td>
                        <td><?php echo $values["qty"]; ?></td>
                        <td><?php echo isset($values["size"])?$values['size']:"no"; ?></td>
                        <td><?php echo $values["price"]." SR" ?></td>
                        <td><?php echo number_format($values["qty"] * $values["price"], 2) . "SR";?></td>
                        
                        </tr>
                    <?php
                    $total = $total + ($values["qty"] * $values["price"]);
                    }  
                    ?> 
                    <tr>
                        <td colspan="6" align="center">Total</td>
                        <td align="center"><?php echo number_format($total, 2) ?> SR</td>
                        
                    </tr>
                    <?php
                    }  
                    ?> 
             </tr>
           </tbody>
        </table>
 <footer>
           <h1> Lolia Jewelry  </h1>
            <ul style="text-align: left">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="homepage.php"> Prodects categories </a></li>
                <li><a href="About_us.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
        </footer>
</body>
</html>
       