<?php
ob_start();
session_start();
include('datab.php');

?>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title> 
        Lolia Jewelry
        </title>
        <style>
            
            .sub_title{
         color: gray;
        font-size: 30px;
       font-weight: 300;
        margin-left: 580px;

         }
            form {
                align-content: center;
                align-items: center;
                padding-left: 47%
                
            }
      
            
        
        </style>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <link rel="stylesheet" type="text/css" href="style.css">
  
   </head>
    
<body>

        <header>
             <h1>Lolia Jewelry</h1>
            <ul style="text-align: top">
               <?php 
               if(!isset($_SESSION['Email'])){
                   ?> 
                   <li> <a href="login.php" class="button">Login</a></li>
                <li><a href="reg.php" class="button">Register </a></li>
                   <?php
               }else{
                  $sql = "SELECT * FROM customer WHERE Email='".$_SESSION['Email']."'";
                  $r = $db_link->query($sql);
                   $row = mysqli_fetch_assoc($r);
                   echo $row['customer_name'];
               }
               ?>

                <li><a href="cart.php"><img src="shopping-cart.png" alt="Shopping cart" width="20" height="20"/> </a></li>
                <?php 
                  if(isset($_SESSION['Email'])){
                      ?>
                      <li> <a href="logout.php" class="button" class="log">Logout</a></li>
                      <?php
                  }
                ?>
               


            
            
              </ul>         
                

                                

            <nav>
            <ul style="text-align: center">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="homepage.php"> Prodects categories </a></li>
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
            </nav>
            
              </ul> 
     </header>
    <section>
    
   

      
   
                    <!-- body section starts  -->

        
        
        
        
        
        
        
        
        
        
        
        
        
        
    
        <br><br><br><br><br>
               <?php 
            
        if(isset($_GET['remove'])){
    $id=$_GET['remove'];
    unset($_SESSION['cart'][$id]);
}
if(isset($_GET['removeall'])){
    unset($_SESSION['cart']);
}
?>
      
  <table width="90%" border="1px" style="border-collapse: collapse; margin-left: 55px;">
           <thead>
             <tr>
               <th>#</th>
               <th>Title</th>
               <th>Qty</th>
               <th>price</th>
               <th>size</th>
               <th>Total price</th>
               <th>Remove</th>


             </tr>
           </thead>
           <tbody>
             <tr>
               <?php
                    if(!empty($_SESSION['cart'])){
                        $total = 0;
                        $i=0;
                        foreach($_SESSION["cart"]as $keys => $values){
                          $i++;
                    ?>
                        <tr align="center">
                          <td><?php echo $i; ?></td>
                        <td><?php echo $values["title"]; ?></td>
                        <td><?php echo $values["qty"]; ?></td>
                        <td><?php echo $values["price"]." SR" ?></td>
                        <td><?php echo $values["size"]; ?></td>
                        <td><?php echo number_format($values["qty"] * $values["price"], 2) . "SR";?></td>
                        <td><a href="?remove=<?php echo $keys; ?>"><span class="text-danger">Remove</span></a></td>
                        </tr>
                    <?php
                    $total = $total + ($values["qty"] * $values["price"]);
                    }  
                    ?> 
                    <tr>
                        <td colspan="6" align="center">Total</td>
                        <td align="center"><?php echo number_format($total, 2) ?> SR</td>
                        <td><a href="?removeall=1"><span class="text-danger" > Clear All</span></a></td>
                    </tr>
                    <?php
                    }  
                    ?> 
      </tr>
           </tbody>
        </table>
            <br>
			
  <a href="Check.php" style= "margin-left: 570px; align:center; outline: none;
  border:none;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 18px;
  font-weight: 500;
  color: #fff;
  background: pink;
  cursor: pointer;">Check out</a>
  
  
<br>
        
        
        
        
        
        
        
        
  
                <br><br><br><br><br>
        <br><br><br><br><br>
        <br><br><br><br><br>
        <br><br><br><br><br>
        <br><br><br><br><br>
    
    
    <?php  
    
        if(isset($_COOKIE['old_purchases'])){ //save old purchases in cookie file
        $old_purchases=unserialize($_COOKIE['old_purchases']); //create variable has list of old purchases
   }
  else{
    $old_purchases=array();// create null list to begninnig
}
$new_purchases='product_name'; // add new product to list
$old_purchases[] = $new_purchases;
//array_push($old_purchases,$new_purchases); //array push to add 1 or more than item 
setcookie('old_purchases',serialize($old_purchases),time()+86400*30,"/"); #cookie for 1 month


?>



   
    
    <footer>
           <h1> Lolia Jewelry  </h1>
            <ul style="text-align: left">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="homepage.php"> Prodects categories </a></li>
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
        </footer>
    </body>
    </html>
    