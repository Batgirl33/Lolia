<?php
ob_start();
session_start();
include('datab.php'); ?>
<!Doctype html>
<html>
<head>
        <title>Checkout</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <meta charset="utf-8"> 
            <meta name="viewport" content="width=device-width, initial-scale=1">
   <style type="text/css">
    
    .h2{
           text-align: center;
        margin: auto
    }
       .y2{
           text-align: right
               margin-right: 50px;
       }
       
    
    
      </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
    <link rel="stylesheet" href="check.css" type="text/css"> 
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    </head>
<body >
 
        <header>
        <header>
             <h1>Lolia Jewelry</h1>
            <ul style="text-align: top">
               <?php 
               if(!isset($_SESSION['Email'])){
                   ?> 
                   <li> <a href="login.php" class="button">Login</a></li>
                <li><a href="reg.php" class="button">Register </a></li>
                   <?php
               }else{
                  $sql = "SELECT * FROM customer WHERE Email='".$_SESSION['Email']."'";
                  $r = $db_link->query($sql);
                   $row = mysqli_fetch_assoc($r);
                   echo $row['customer_name'];
               }
               ?>

                <li><a href="cart.php"><img src="shopping-cart.png" alt="Shopping cart" width="20" height="20"/> </a></li>
                <?php 
                  if(isset($_SESSION['Email'])){
                      ?>
                      <li> <a href="logout.php" class="button" class="log">Logout</a></li>
                      <?php
                  }
                ?>
               


            
            
              </ul>         
                

                                

            <nav>
            <ul style="text-align: center">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="homepage.php#prodects"> Prodects categories </a></li>
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
            </nav>
            
              </ul> 
     </header>
         

    <?php 
       
     if (!isset($_SESSION['cart'])) {
         echo "<h1 style='text-align:center;color:Red'>Please Add product in cart</h1>";
     }

     ?>
<a style= "color: darkred;"><h2> Billing Address </h2></a>

<?php 
if (isset($_POST['submit'])) {
    
 
   setcookie ("order",json_encode($_SESSION['cart']),strtotime("+1 year"));            //cookie
     

	 
    
  foreach ($_SESSION['cart'] as $key => $value) {
	 $sql = "UPDATE product SET quantity = quantity-'".$value['qty']."' WHERE product_id='".$value['id']."'";
     $r  = $db_link->query($sql);
  }
     if ($r) {
       echo "<h1>Your order has successfully placed</h1>";
	   }
	  if ($value['qty'] = 0){
	   echo "<h1>Your order has no quantity</h1>";
      }
	   
	   }
 
?>
<div class="row">
  <div class="col-75">
    <div class="container">
      <form action=" " method="post" onsubmit="return false">
      
        <div class="row">
          <div class="col-50">
            <h3>Billing Address</h3>
            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
            <input type="text" id="fname" name="firstname" placeholder="John M. Doe" >
            <small style='color: red;' id="fname_error" ></small>
            <label for="email"><i class="fa fa-envelope"></i> Email</label>
            <input type="text" id="email" name="email" placeholder="john@example.com">
                        <small style='color: red;' id="email_error" ></small>
            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
            <input type="text" id="adr" name="address" placeholder="542 W. 15th Street">
                        <small style='color: red;' id="address_error"></small>
            <label for="city"><i class="fa fa-institution"></i> City</label>
            <input type="text" id="city" name="city" placeholder="New York">
                        <small style='color: red;' id="city_error"></small>

          
          </div>

          <div class="col-50">
            <h3>Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">Name on Card</label>
            <input type="text" id="cname" name="cardname" placeholder="John More Doe">
            <small style='color: red;' id="cname_error" ></small>

            <label for="ccnum">Credit card number</label>
            <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444">
            <small style='color: red;' id="ccnum_error" ></small>

            <label for="expmonth">Exp Month</label>
            <input type="text" id="expmonth" name="expmonth" placeholder="1 to 12">
                 <small style='color: red;' id="expmonth_error" ></small>
           

            <div class="row">
              <div class="col-50">
                <label for="expyear">Exp Year</label>
                <input type="text" id="expyear" name="expyear" placeholder="2026">
                 <small style='color: red;' id="expyear_error" ></small>
                   
              </div>
              <div class="col-50">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" placeholder="352">
            <small style='color: red;' id="cvv_error" ></small>

              </div>
               
            </div>
          </div>
          
        </div>
        <label>
          <input type="checkbox" checked="checked" name="sameadr"> Shipping address same as billing
            
        </label>
        <?php 
          if(isset($_SESSION['Email'])){
              
          
        ?>
          <input type="submit" value="Continue to checkout" name='submit' class="btn btn-submit"  >
          <?php 
          }else{
              echo "<h3 style='color:Red;text-align:Center'>PLease login to checkout</h3>";
          }
          ?>
		   <a href="homepage.php" class="button">Back to Home page </a>
        </form>
          </div>
      
  </div>
  
    
  </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
  $(".btn-submit").click(function(){
    var firstname = $("#fname").val();
    var email = $("#email").val();
    var address = $("#adr").val();
    var city = $("#city").val();
    var cname = $("#cname").val();
    var ccnum = $("#ccnum").val();
    var expmonth = $("#expmonth").val();
    var expyear = $("#expyear").val();
    var cvv = $("#cvv").val();
    if(firstname.length<1){
      $("#fname_error").text("PLease Enter Firstname");
    }else{
      $("#fname_error").text(" ");

    }
    if(address.length<1){
      $("#address_error").text("PLease Enter Address");
    }else{
      $("#address_error").text(" ");

    }
    if(city.length<1){
      $("#city_error").text("PLease Enter City");
    }else{
      $("#city_error").text(" ");

    }
    function IsEmail(email) {
        var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if(!regex.test(email))
         {
           return false;
        }else
        {
           return true;
        }
      }
    if(IsEmail(email)==false){
      $("#email_error").text("PLease Enter Valid Email");
    }else{
      $("#email_error").text(" ");

    }
   if (cname.length<1) {
    $("#cname_error").text("Please Enter Card Name");
   }else{
    $("#cname_error").text(" ");
   }
    if (ccnum.length<1) {
    $("#ccnum_error").text("Please Enter Card Number");
   }else{
    $("#ccnum_error").text(" ");
   }
   if (expyear< <?php echo date('Y'); ?>) {
    $("#expyear_error").text("Please Enter Valid year");
   }else{
    $("#expyear_error").text(" ");
   }
   if (expmonth< <?php echo date('n'); ?>) {
    $("#expmonth_error").text("Please Enter Valid month");

   }else{
    $("#expmonth_error").text(" ");

   }
   if (cvv.length<1 || cvv.length>3) {
    $("#cvv_error").text("Please Enter Valid cvv");
   }else{
    $("#cvv_error").text(" ");
   }
   
   if (firstname.length>1 && address.length>1 && city.length>1 && IsEmail(email)==true && cname.length>1 && ccnum.length>1 && expyear><?php echo date('Y'); ?> &&  expmonth>=<?php echo date('n') ?> && cvv.length>1 && cvv.length<4 ) {
    $("form").attr("onsubmit","return true");
   }

  });
 
</script>
    
    <footer>
           <h1> Lolia Jewelry  </h1>
            <ul style="text-align: left">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="homepage.php"> Prodects categories </a></li>
                <li><a href="About_us.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
        </footer>
   
    </body>


</html>