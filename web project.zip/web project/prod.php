<?php 
ob_start();
session_start();
include('datab.php');
function idtodata($table,$column,$id){
            include('datab.php');
            $sql = "SELECT $column FROM $table WHERE product_id='$id'";
            $run = $db_link->query($sql);

            if (mysqli_num_rows($run)>=1) {
                $data = $run->fetch_assoc();
                return $data[$column];
            }
           }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link  rel='stylesheet' href='style.css'>
    <!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
     <title> <?php 
            if (isset($_GET['id'])) {
              $id = $_GET['id'];
              $sql = "SELECT * FROM product WHERE product_id='$id'";
              $r = $db_link->query($sql);
              $row = mysqli_fetch_assoc($r);
              echo $row['product_name'];
            }
    ?> </title>
    <link rel="stylesheet" href="ProductDetailes.css">
    <style>
            section h4 {
                font-size: 20px;
                margin: auto;
                transform: translate(23%, 850%);
            
                }
        section h1 { 
            font-size: 60px;
            margin-bottom: auto;
            transform: translate(24%, 110%);
        
            }
            strong {
                font-size: 200%;
            }
            marquee h1{
                font-size: 300%
            }
            .log{
               float: left;
                align-content: center;
            
                
                
            }
 
        
        </style>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
      <!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
   </head>
   
<body>
    <!-- nav section starts  -->
    <section>
 <header>
             <h1>Lolia Jewelry</h1>
           <ul style="text-align: top">
               <?php 
               if(!isset($_SESSION['Email'])){
                   ?> 
                   <li> <a href="login.php" class="button">Login</a></li>
                <li><a href="reg.php" class="button">Register </a></li>
                   <?php
               }else{
                  $sql = "SELECT * FROM customer WHERE Email='".$_SESSION['Email']."'";
                  $r = $db_link->query($sql);
                   $row = mysqli_fetch_assoc($r);
                   echo $row['customer_name'];
               }
               ?>

                <li><a href="cart.php"><img src="shopping-cart.png" alt="Shopping cart" width="20" height="20"/> </a></li>
                <?php 
                  if(isset($_SESSION['Email'])){
                      ?>
                      <li> <a href="logout.php" class="button" class="log">Logout</a></li>
                      <?php
                  }
                ?>
               


            
            
              </ul> 
            <nav>
            <ul style="text-align: center">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="homepage.php#prodect">Prodects categories</a></li>
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
            </nav>
        </header>
    </section>
    
    <br><br><br><br><br>
     <?php 
                         
        //CHeck whether submit button is clicked or not
        if(isset($_POST['id']))
        {
            // Get all the details from the form
            $id = $_POST['id'];
           $p_qty =  idtodata('product','quantity',$id);
            $title = idtodata('product','product_name',$id);
            $price = idtodata('product','product_price',$id);
            $qty = $_POST['qty'];
             $size = $_POST['size'];
             if ($p_qty>=$qty) {
                 
             
            if(isset($_SESSION["cart"]))
            {  
                $item_array_id = array_column($_SESSION["cart"], "id");
               if(in_array($_POST["id"], $item_array_id))
                {

                
                 foreach($_SESSION['cart'] as $key => $value)
                     {
                       if ($value['id']==$_POST['id']) 
                       {
                         if ($value['qty']>=$p_qty) {
                            echo '2';
                         }else{
                            
                            $_SESSION['cart'][$key]['qty']+=$qty;
                         }
                          
                       }
  
                    }

                 } else{

                     $item_array = array(
                    'id'      =>  $_POST['id'],
                    'title'         =>  $title,
                    'price'        =>  $price,
                    'qty'          => $qty,
                    'size'      => $size
            );
            $_SESSION["cart"][] = $item_array;
                 }
               
        }
        else
        {
            $item_array = array(
                    'id'      =>  $_POST['id'],
                    'title'         =>  $title,
                    'price'        =>  $price,
                    'qty'          => $qty,
                    'size'         => $size
                   
            );
            $_SESSION["cart"][] = $item_array;
           
        }
        header("location:cart.php");
    }else{
        echo '<h3 class="text-white bg-danger">Out of stock</h3>';
    }
    }
    ?> 
    <section>
      
   <div class="container2">
   
        <?php 
            if (isset($_GET['id'])) {
              $id = $_GET['id'];
              $sql = "SELECT * FROM product WHERE product_id='$id'";
              $r = $db_link->query($sql);
             while($row = mysqli_fetch_assoc($r)){
              ?> 
              <form action="" method="post">
                  <input type='hidden' name='id' value='<?php echo $row["product_id"]; ?>'>
              <div class="box one">
      <div class="details">
        <div class="topic">Description</div>
              <p>
            
         <?php
             echo $row['product_descreption'];
          ?>
          </p><hr>
       <p> Sold & Delivered by Lolia Jewelry</p>
           <input type="number" name="qty" class="qty_validate" value="1" min="1" max="<?php echo $row['quantity']; ?>">

            <select name="size" >
             <option>select size</option>
             <?php 
   $explode  = explode(",",$row['size']);
   foreach ($explode as $key => $value) {
     echo "<option value='$value'> $value </option>";
   }
             ?>
           </select>
          <div class="price-box">
       
            <div class="price"><?php echo $row['product_price']; ?> SR</div>
          </div>
      </div>
      <small id="errormsg" style="color:Red"> </small>
      <div class="button1">
	  <?php 
          if ($row['quantity']<1) {
            echo "<p>Product is out of stock</p>";
          }else{
    if(isset($_SESSION['Email'])){
        
    
      ?>
			
        <button type="submit" class="Submit_button" name="submit">Add To Cart</button>
		
          <!-- Button to Open the Modal -->
<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#myModal">
  Help
</button>

<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Help Window</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal" ><i class="fa fa-times" aria-hidden="true"></i>
</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       <p>Welcome in our website if you want more information please contact with </p>
       <a href='contact.php' class='btn btn-outline-success'>Contact us</a>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
		 <?php
        
    }else{
       echo "<h3 style='color:red'>Login to buy product</h3>";
    }
          }
        ?>
      </div>
      </form>
       </div>
    <div class="box two">
      <div class="image-box">
        <div class="image">
          <img src="image/<?php echo $row['product_pic']; ?>" alt="Erring">
        </div>
        <div class="info">
          <br><br> 
       
          <div class="shipping" align="center" >
              <a><?php echo $row['product_name']; ?></a><br>
              <a>FREE SHIPPING</a>
                  </div>
          </div>
        </div>
      </div>
    </div>
  

              <?php
             }
            }
    ?> 
       
   </section>

    <br><br><br><br><br><br><br><br>     <br>
    <br>
    <br>
    <br>
   <br>   <br>

