
<?php 
 include('datab.php');
  if (isset($_GET['id'])) {
      $id = $_GET['id'];

      $sql  = "DELETE FROM product WHERE  product_id= '".$id."'";
      $r=mysqli_query($db_link,$sql);
      if ($r) {
          header("Location:Adminpage.php");
          echo"Deleted successfull";
      }else{
        die(mysqli_error($db_link));
      }
  }
   
?>
