<?php 
ob_start();
session_start();
include "datab.php";
function idtodata($table,$column,$id){
            include('datab.php');
            $sql = "SELECT $column FROM $table WHERE product_id='$id'";
            $run = $db_link->query($sql);

            if (mysqli_num_rows($run)>=1) {
                $data = $run->fetch_assoc();
                return $data[$column];
            }
           }
?>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <title> 
        Lolia Jewelry
        </title>
        <style>
            section h4 {
                font-size: 20px;
                margin: auto;
                transform: translate(23%, 850%);
            
                }
        section h1 { 
            font-size: 60px;
            margin-bottom: auto;
            transform: translate(24%, 110%);
        
            }
            strong {
                font-size: 200%;
            }
            marquee h1{
                font-size: 300%
            }
            .log{
               float: left;
                align-content: center;
            
                
                
            }
 
        
        </style>
    <link rel="stylesheet" type="text/css" href="style.css">
         <link rel="stylesheet" href="adminstyle.css" href="style2.css"  type="text/css">
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
        
    </head>
<boday>
    <div class="bac">
        <header>
             <h1>Lolia Jewelry</h1>
           <ul style="text-align: top">
               <?php 
               if(!isset($_SESSION['Email'])){
                   ?> 
                   <li> <a href="login.php" class="button">Login</a></li>
                <li><a href="reg.php" class="button">Register </a></li>
                   <?php
               }else{
                  $sql = "SELECT * FROM customer WHERE Email='".$_SESSION['Email']."'";
                  $r = $db_link->query($sql);
                   $row = mysqli_fetch_assoc($r);
                   echo $row['customer_name'];
               }
               ?>

                <li><a href="cart.php"><img src="shopping-cart.png" alt="Shopping cart" width="20" height="20"/> </a></li>
                <?php 
                  if(isset($_SESSION['Email'])){
                      ?>
                      <li> <a href="logout.php" class="button" class="log">Logout</a></li>
                      <?php
                  }
                ?>
               


            
            
              </ul> 
            <nav>
            <ul style="text-align: center">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="#prodect">Prodects categories</a></li>
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
            </nav>
        </header>
        
        
        <div>
            
        <section>
            <br>
            <br>
            <h1>Welcome to <br> Lolia shope</h1>
            <br>
            <br>
            <br>
            <br>
            <br>
              <br>
            <spam><button ondblclick="myalert()">
      Help
    </button></spam>
               <script>
        function myalert() {
            alert("welcome to our Lolia shope you can see our proudect here in home page and have a nice time with us.. if you have any question please contact us");
        }
    </script>
            
            </section>
        </div>
        <div>
            <br>               
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>

            <marquee bgcolor="ghostwhite" id="prodect">
            <h1>Our Proudect</h1>
        </marquee>
            
            <br>
            <br>
            
    <div class='container-fluid'>
         <div class='row'>
             
                  
             
           
          <?php 

  if (isset($_SESSION['msg'])) {
      echo $_SESSION['msg'];
      $_SESSION['msg'] = NULL;
  }
?>
     <br>
   
                   
    <?php 
                            
        $query = "SELECT * FROM product";
       $r = $db_link->query($query);
            
         $count = mysqli_num_rows($r); 
      if ($count>=1) {
    $i = 1;
   while ($row = mysqli_fetch_assoc($r)) {
     $name  = $row['product_name'];
     $description  = $row['product_descreption'];
     $quantity = $row['quantity'];
     $Availability = $row['Availability'];
     $size  = $row['size'];
       
     if (empty($quantity)) {
         $quantity = "No";
     }
     $size  = $row['size'];
     if (empty($size)) {
         $size = "No";
     }
     $price  = $row['product_price'];
   
      
        ?>
     <div class='col-lg-4 col-md-6 col-sm-12 mt-4'>
<div class="card">
  <img class="card-img-top" src="image/<?php echo $row['product_pic']; ?>" alt="Card image" style='height:450px'>
  <div class="card-body">
    <h4 class="card-title"><?php echo $row['product_name']; ?></h4>
    <p class="card-text">price : <?php  echo $price; ?> SR</p>
    <a href="prod.php?id=<?php echo $row['product_id']; ?>" class="btn btn-primary">View</a>
  </div>
</div>
</div>
        <?php
          $i++;
   }
 }

                            ?>
                         
         </div>
    </div>  
                           
                 
                         
                        <script type="text/javascript">
    function performSearch() {

  // Declare search string 
  var filter = searchBox.value.toUpperCase();

  // Loop through first tbody's rows
  for (var rowI = 0; rowI < trs.length; rowI++) {

    // define the row's cells
    var tds = trs[rowI].getElementsByTagName("td");

    // hide the row
    trs[rowI].style.display = "none";

    // loop through row cells
    for (var cellI = 0; cellI < tds.length; cellI++) {

      // if there's a match
      if (tds[cellI].innerHTML.toUpperCase().indexOf(filter) > -1) {

        // show the row
        trs[rowI].style.display = "";

        // skip to the next row
        continue;

      }
    }
  }

}

// declare elements
const searchBox = document.getElementById('searchBox');
const table = document.getElementById("myTable");
const trs = table.tBodies[0].getElementsByTagName("tr");

// add event listener to search box
searchBox.addEventListener('keyup', performSearch);
</script>
                    </table> 

           

        <footer>
           <h1> Lolia Jewelry  </h1>
            <ul style="text-align: left">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="#prodect"> Prodects categories </a></li>
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
        </footer>
    </div>
    
    
    </boday>

</html>