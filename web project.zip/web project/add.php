<?php 
ob_start();
include('datab.php'); ?>
<?php 

if ($_POST) {
    $product_name    = trim($_POST['name']);
    $price   = $_POST['price'];
    $qty     = $_POST['qty'];
    $image   = $_FILES['image']['name'];
    $image_file  = $_FILES['image']['tmp_name'];
    $description = trim($_POST['description']);
    $size = $_POST['size'];

    try {
        $sql = "INSERT INTO product( product_name, product_price, quantity, product_pic, product_descreption,size) 
                VALUES('$product_name','$price','$qty','$image','$description','$size')";

        if ($db_link->query($sql)) {
            move_uploaded_file($image_file,'image/'.$image);
    header("location:create.php?status=created");
   }else{
    echo $db_link->error;
   }
    } catch (Exception $e) {
        echo "Error " . $e->getMessage();
        exit();
    }
} else {
    header("Location: create.php?status=fail_create");
    exit();
}
?>