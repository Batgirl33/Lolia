<html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="stylesheet" href="adminstyle.css" href="style2.css".css type="text/css">
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
      
    <title> 
        Lolia Jewelry
        </title>
        <style type="text/css">
            h1 {
               text-align: center; 
  
            }
            .bacg{
                background-color:white;
                align-items: center;
                align-content: center;
                
                
            }
             .box {border: 1px solid black;}
            
            br {
             clear:both;
            }

                   section  div 
            { width:50%;height:40%;
            background-color: whitesmoke;
            text-align:center;
            border: 4px solid black ;
            float:inherit;
            margin:1%;
            align-content: center;
        } 
            section{
                align-content: center;
                justify-content: center;
                place-content: center;
                
            }
            .tab{
                margin: inherit;
                padding: inherit;
                text-align: center;
                
                
                
            }
             nav a{
            text-decoration: none;
            color:blueviolet;
            margin: 1px;
        }   
        

        </style>
    <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
    <header>
             <h1>Lolia Jewelry</h1>
           <ul style="text-align: top">
                <li> <a href="login.php" class="button">Login</a></li>
                <li><a href="reg.php" class="button">Register </a></li>
                <li><a href="cart.php"><img src="shopping-cart.png" alt="Shopping cart" width="20" height="20"/> </a></li>
               <li> <a href="logout.php" class="button" class="log">Logout</a></li>


            
            
              </ul> 
            <nav>
            <ul style="text-align: center">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="homepage.php"> Prodects categories </a></li>
                
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
            </nav>
        </header>
        <section class="bacg">
       
        
<h1> welcome to Admin page</h1>
            <nav class="a" style="text-align: center">
            <br>
              <span >
                    <a href="create.php" >Add Product</a>
                    <span>||</span>
                    <a href="Adminpage.php" >Manage Products</a>
                   </span>
            </nav>
              
            
<br><br>
            
          <?php include('datab.php'); ?>
  
<?php 

  if (isset($_SESSION['msg'])) {
      echo $_SESSION['msg'];
      $_SESSION['msg'] = NULL;
  }
?>
     <br>
    <input type="search"  id="searchBox" style="width:100%" placeholder="Enter something for search...">
                    <table id="myTable" class="tab" style="margin:inherit padding:inherit  text-align: center;">
                        <thead>
                            <th> #  </th>
                            <th>     Image         </th>
                            <th>    Product_name    </th>
                            
                            <th>    Product_descreption    </th>
                            
                            <th>Quantity</th>
                            
                            
                            <th>   Size   </th>
                            
                            <th>Product_price</th>
                            
                            <th colspan="3">Action</th>
                        </thead>
                        <tbody>
    <?php 
                            
        $query = "SELECT * FROM product";
       $r = $db_link->query($query);
            
         $count = mysqli_num_rows($r); 
      if ($count>=1) {
    $i = 1;
   while ($row = mysqli_fetch_assoc($r)) {
     $name  = $row['product_name'];
     $description  = $row['product_descreption'];
     $quantity = $row['quantity'];
     $size  = $row['size'];
       
     if (empty($quantity)) {
         $quantity = "No";
     }
     $size  = $row['size'];
     if (empty($size)) {
         $size = "No";
     }
     $price  = $row['product_price'];
   
      
        ?>
        <tr>
                                <td><?php echo $i; ?></td>
                                <td><img src="<?php echo "image/" .$row['product_pic']; ?>" width='50px'></td>
                                <td><?php  echo $name;?></td>
                                <td><?php echo $description; ?></td>
                                <td><?php echo $quantity; ?></td>
                                <td><?php echo $size; ?></td>
                                <td><?php echo $price."SR"; ?></td>
            
                                <td><form action="editpro.php?id=<?php echo $row['product_id']; ?>" method="post"><button style= color:blue type="submit"> Edit </button></form>  </td>
                                <td><form action="delete.php?id=<?php echo $row['product_id']; ?>" method="post"><button style= color:red type="submit" onclick="event2()"> Delete </button></form></td>
            
                                
                            </tr>
        <?php
          $i++;
   }
 }

                            ?>
                            
                           
                            
                        </tbody>
                    </table>

              
         



<script type="text/javascript">
    function performSearch() {

  // Declare search string 
  var filter = searchBox.value.toUpperCase();

  // Loop through first tbody's rows
  for (var rowI = 0; rowI < trs.length; rowI++) {

    // define the row's cells
    var tds = trs[rowI].getElementsByTagName("td");

    // hide the row
    trs[rowI].style.display = "none";

    // loop through row cells
    for (var cellI = 0; cellI < tds.length; cellI++) {

      // if there's a match
      if (tds[cellI].innerHTML.toUpperCase().indexOf(filter) > -1) {

        // show the row
        trs[rowI].style.display = "";

        // skip to the next row
        continue;

      }
    }
  }

}

// declare elements
const searchBox = document.getElementById('searchBox');
const table = document.getElementById("myTable");
const trs = table.tBodies[0].getElementsByTagName("tr");

// add event listener to search box
searchBox.addEventListener('keyup', performSearch);
                                    
                                    
                           
         function event2()
    {
       alert("delete successful") 
        
        
    }                            
                                    
</script>
            
            
    <footer>
           <h1> Lolia Jewelry  </h1>
            <ul style="text-align: left">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="homepage.php"> Prodects categories </a></li>
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
        </footer>

    </body>
    </html>