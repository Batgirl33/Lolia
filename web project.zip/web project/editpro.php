<?php include('datab.php'); ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>

    <title>Edit Product </title>
    <link rel="stylesheet" href="style.css"  type="text/css">
   
       <!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      
   
   </head>
<body>
    <header>
             <h1>Lolia Jewelry</h1>
           <ul style="text-align: top">
                <li> <a href="login.php" class="button">Login</a></li>
                <li><a href="reg.php" class="button">Register </a></li>
                <li><a href="cart.html"><img src="shopping-cart.png" alt="Shopping cart" width="20" height="20"/> </a></li>
               <li> <a href="logout.php" class="button" class="log">Logout</a></li>


            
            
              </ul> 
            <nav>
            <ul style="text-align: center">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="#prodect">Prodects categories</a></li>
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
            </nav>
        </header>
    <!-- image section starts  -->

    <a href="Adminpage.php" class="btn btn-light mb-3"><< Go Back</a> 
<?php
     include('datab.php');
     if(isset($_GET['id'])){
     $id = $_GET['id'];
     $sql2 = "SELECT * FROM product WHERE product_id='".$_GET['id']."'";
     $r =$db_link->query($sql2);
     while($row  = mysqli_fetch_assoc($r)){
     $r_name  = $row['product_name'];
     $r_description  = $row['product_descreption'];
     $r_qty = $row['quantity'];
     $r_price  = $row['product_price'];
     $r_image = $row['product_pic'];
     $r_size = $row['size'];
     }
  }
      
 
    $id=$_GET['id'];
 if(isset($_POST['submit'])){
    $name =$_POST['name'];
    $price = $_POST['price'];
    $qty  =  $_POST['qty'];
    $image  =$_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];
    $size = $_POST['size'];
    if(strlen($image)<2){
        $image = $r_image;
    }
    
    $description = $_POST['description'];
    
     $sql = "UPDATE product SET  product_name = '$name', product_price = '$price' , quantity = '$qty', product_pic = '$image', product_descreption = '$description',size = '$size' WHERE product_id = '$id'";
     $r=mysqli_query($db_link,$sql);
      if ($r) {
          echo"Updated successfull";
          header("Location:Adminpage.php");
          
      }else{
        die(mysqli_error($db_link));
      }
  }
   
     ?>
                  <!-- Create Form -->
        <div class="card border-danger">
            <div class="card-header bg-danger text-white">
                <strong><i class="fa fa-plus"></i> Edit Product</strong>
            </div>
            <div class="card-body">
                <form action=" " method="post" enctype='multipart/form-data' >
                    <div class="form-row">
                        
                        <div class="form-group col-md-6">
                            <label for="name" class="col-form-label">Name</label>
                            <input type="text" class="form-control" id="title"  value="<?php echo isset($r_name)?$r_name:" " ?>" name="name" placeholder="Name" required>
                        </div>
                         <div class="form-group col-md-6">
                            <label for="name" class="col-form-label">Size</label>
                            <input type="text" class="form-control" id="size"  value="<?php echo isset($r_size)?$r_size:" " ?>" name="size" placeholder="size" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="price" class="col-form-label">Price</label>
                            <input type="number" class="form-control" id="product_price" name="price" value="<?php echo isset($r_price)?$r_price:" " ?>" placeholder="Price" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="qty" class="col-form-label">Qty</label>
                            <input type="number" class="form-control" name="qty" id="stock" placeholder="Qty" required value="<?php echo isset($r_qty)?$r_qty:" " ?>">
                        </div>
                        <div class="form-group col-md-4">
                             <img src='image/<?php echo $r_image ?>' width='200px'>
                            <label for="image" class="col-form-label">Image</label>
                           <input type='file' name='image' id='file' >
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="note" class="col-form-label">Description</label>
                        <textarea name="description" id="product_descreption" rows="5" class="form-control" placeholder="Description"><?php echo isset($r_description)?$r_description:" " ?></textarea>
                    </div>
                    <button type="submit"  id="submit" name='submit' class="btn btn-success" onclick="event2()"><i class="fa fa-check-circle"></i> Save</button>
                </form>
            </div>
        </div>
                

          
        <!-- // Page Wrapper -->


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#submit").click(function(){
            var title = $("#title").val();
            var description = $("#product_descreption").val();
            var quantity = $("#stock").val();
            var file = $("#file").val();
            var size = $('#size').val();
            var price = $("#product_price").val();
            if ($.trim(title)==" " || title.length<5) {
                  $(".t_error").text("PLease Write title greater than 5 characters");
            }else{
                  $(".t_error").text(" ");

            }
            if ($.trim(description)==" " || description.length<20) {
                  $(".p_error").text("PLease Write description Greater than 20 characters");
            }else{
                  $(".p_error").text(" ");

            }
            if ($.trim(quantity)<1) {
                  $(".s_error").text("Enter Quantity of product");
            }else{
                  $(".s_error").text(" ");

            }
            if ($.trim(price)<1) {
                  $(".r_error").text("Enter Price of product");
            }else{
                  $(".r_error").text(" ");

            }
           
            if (size.length<1) {
                  $(".c_error").text("PLease Select The Size of product");
            }else{
                  $(".c_error").text(" ");

            }
        if ($.trim(title)!=" " && title.length>5 && $.trim(description)!=" " && description.length>20 && $.trim(quantity)>1 && $.trim(price)>1  && size.length>1 ) {
            $("form").attr("onsubmit","return true");
           
        }else{
            $("form").attr("onsubmit","return false");
            
        }
        })
    })
     function event2()
    {
       alert("Edit successful") 
        
        
    }
</script>
    
    
    
    
        <footer>
           <h1> Lolia Jewelry  </h1>
            <ul style="text-align: left">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="homepage.php"> Prodects categories </a></li>
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
        </footer>
    
    </body>

</html>