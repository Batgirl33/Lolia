<html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
    <title> 
        Lolia shope Login
        </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
        
        </style>
        <link rel="stylesheet" type="text/css" href="Registrationstyle.css" >
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

        
    </head>
    <body>
     <?php include('datab.php'); ?>
        <?php 
  if (isset($_POST['username'])) {
	$name = $_POST['username'];
	$email = $_POST['email'];
  	$password = $_POST['password'];
	$cpass = $_POST['password2'];

	
	
  	$sql = "SELECT *  FROM customer WHERE Email='$email' AND Password='$password'";
  	$r  = $db_link->query($sql);
  	$count = mysqli_num_rows($r);

      if ($count>=1) {
       $_SESSION['username'] = $username;
       header("location:homepage.php");
      }else{
		  if($password != $cpass){
         $message[] = 'confirm password not matched!';
		 $msg = "<h1 style=color:red>Enter Correct Information</h1>";
       }else{
		 $sql = "INSERT INTO `customer`(Email, Password, customer_name,customer_contact) VALUES( '$email','$cpass', '$name',' ')";
         if($db_link->query($sql)){
             $message[] = 'registered successfully!';
         }else{
             echo $db_link->error;
         }
         
        
         header('location:homepage.php');
      }
    
      }

  }

  
?>
  <section class="text">
  	<?php
  if (isset($msg)) {
  echo $msg;
  }else{
  	?>
        <h1 style="font-size: 26px; font-weight: 600; color: #8B0000; text-align: center;">
            Welcome to our family <br></h1>
  	<h2 class="text-2"> Register Now </h2><br>
      
  	<?php
  }
      
  	 ?>
  	
        
        
    <div class="wrapper">
    <h2>Registration</h2>
    <form action="" method="post">
      <div class="input-box">
        <input type="text" name="username" placeholder="Enter your name" required>
      </div>
      <div class="input-box">
        <input type="text" name="email" placeholder="Enter your email" required>
      </div>
      <div class="input-box">
        <input type="password" name="password"placeholder="Create password" required>
      </div>
      <div class="input-box">
        <input type="password" name="password2" placeholder="Confirm password" required>
      </div>
      <div class="policy">
        <input type="checkbox" class="checkbox">
        <h3>I accept all terms & condition</h3>
      </div>
      <div class="input-box button">
        <input type="Submit" value="Register Now">
      </div>
      <div class="text">
        <h3>Already have an account? <a href="login.php">Login now</a></h3>
          <h3><a href="homepage.php">Back to the Home page</a></h3>
      </div>
    </form>
  </div>
    
    
    </body>
    </html>