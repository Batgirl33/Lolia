<?php 

$query = "SELECT * FROM product";

$db_link = mysqli_connect("localhost:3307", "root", ""); 
    
    

if(!$db_link )
{

die("Could not connect to MySQL </body> </html>");
}
     
    

if (!mysqli_select_db($db_link,"lolia1"))
    
{
die("Could not open products database . </body> </html>");
}


/*if ( !( $result = mysqli_query($db_link, $query) ) )
{
print( "<p>Could not execute query!</p>" );
die ();
}
    while($row = mysqli_fetch_row($result))
    {
     print("<tr>");
        foreach($row as $value)
            print("<td>$value </td>");
            print("</tr>");  
    }



*/

?>