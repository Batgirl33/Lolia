<?php 
ob_start();
session_start();
include 'datab.php';
?>
<!DOCTYPE html>
<html>
<html>
    <head>
    <title>Contact Us</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <meta charset="utf-8"> 
            <meta name="viewport" content="width=device-width, initial-scale=1">
   <style type="text/css">
       
       .body{
           width: 100%;
           height: 100vh;
        background: url("download.jpeg") no-repeat center;
           background-size: cover;
           z-index: -1;
       
           
       }
       .h2{
           text-align: center;
        margin: auto
    

       }
       .form{
           max-width: 850px;
           margin: auto;
           padding: 0px;
           overflow: hidden;
          display:grid;
        
         
       }
       .contact-form-text{
           display: block;
           width: 100%;
           box-sizing: border-box;
           margin: 10px 0;
           border: 0;
          padding: 10px 40px; 
           outline: none;
         background-color: whitesmoke;
           color: white
          
           
       }
       .submit{
          margin: 20px 0px;
           width: 5%;
           outline: none;
           
       }
        
        </style>
        
    </head>
<body class="body" >
 
        <header>
             <h1>Lolia Jewelry</h1>
            <ul style="text-align: top">
               <?php 
               if(!isset($_SESSION['Email'])){
                   ?> 
                   <li> <a href="login.php" class="button">Login</a></li>
                <li><a href="reg.php" class="button">Register </a></li>
                   <?php
               }else{
                  $sql = "SELECT * FROM customer WHERE Email='".$_SESSION['Email']."'";
                  $r = $db_link->query($sql);
                   $row = mysqli_fetch_assoc($r);
                   echo $row['customer_name'];
               }
               ?>

                <li><a href="cart.php"><img src="shopping-cart.png" alt="Shopping cart" width="20" height="20"/> </a></li>
                <?php 
                  if(isset($_SESSION['Email'])){
                      ?>
                      <li> <a href="logout.php" class="button" class="log">Logout</a></li>
                      <?php
                  }
                ?>
               


            
            
              </ul>         
                

                                

            <nav>
            <ul style="text-align: center">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="homepage.php"> Prodects categories </a></li>
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
            </nav>
            
              </ul> 
     </header>
    
    <div class="contact-section"></div>
         <h2 class="h2">Contact Us </h2>
         <?php 
         if(isset($_POST['submit'])){
           $username = $_POST['username'];
           $email  = $_POST['email'];
           $phone_number = $_POST['number'];
           $message = $_POST['message'];
    $to = "enter your email";
$subject = "User contact";
$txt = 'name:'.$username.' '.'email:'.$email.' '."Phone Number".' '.'Message'.$message;
$headers = "From: info@fastserveitsolutions.com";

if(mail($to,$subject,$txt,$headers)){
    echo "<h3 style='color:green'>Message have successfully sent</h3>";
}else{
    echo 'not send';
}
         }
         
         ?>
    <form class="form" action=" " method="post">
    <input type="text" name='username' class="contact-form-text" placeholder="Your name">
         <input type="email" name='email' class="contact-form-text" placeholder="Your Email">
         <input type="text" name='number' class="contact-form-text" placeholder="Your Phone Number">
        <textarea class="contact-form-text" name='message' placeholder="Your message"></textarea>
        <input type="submit" name='submit'class="submit" value="send"  >     
 </form>
    


    
    
    
    
    
    
    
    <footer>
           <h1> Lolia Jewelry  </h1>
            <ul style="text-align: left">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="homepage.php"> Prodects categories </a></li>
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
        </footer>
   
    </body>
    </html>