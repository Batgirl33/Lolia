<?php 
ob_start();
session_start();
include 'datab.php';
?>
<!Doctype html>
<html> 
<head>

    <title>About US </title>
    <link rel="stylesheet"type="text/css"href="style.css">
</head>
    <body style="background-color:white">
         <header>
             <h1>Lolia Jewelry</h1>
           <ul style="text-align: top">
               <?php 
               if(!isset($_SESSION['Email'])){
                   ?> 
                   <li> <a href="login.php" class="button">Login</a></li>
                <li><a href="reg.php" class="button">Register </a></li>
                   <?php
               }else{
                  $sql = "SELECT * FROM customer WHERE Email='".$_SESSION['Email']."'";
                  $r = $db_link->query($sql);
                   $row = mysqli_fetch_assoc($r);
                   echo $row['customer_name'];
               }
               ?>

                <li><a href="cart.php"><img src="shopping-cart.png" alt="Shopping cart" width="20" height="20"/> </a></li>
                <?php 
                  if(isset($_SESSION['Email'])){
                      ?>
                      <li> <a href="logout.php" class="button" class="log">Logout</a></li>
                      <?php
                  }
                ?>
               


            
            
              </ul> 
            <nav>
            <ul style="text-align: center">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="homepage.php"> Prodects categories </a></li>
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
            </nav>
        </header>
        
        
        <section calss="about">
            <div class="main"></div>
            <center><img src="M.webp" width="600" height="500"/></center>         

            <br>
            <div class="about-text"></div>
           <center><h1>About US</h1></center>
            <center><h2><em>Lolia Jewelry online shop</em></h2></center>
        </section>         
        <p>                 
        <center><h4>Every story has a beginning,and every starting an online website has a successful way to achieve the higest emphasize the satisfaction of customer about our online website and the quality of services and products that we sell.Actually, we are an online site for Jewelry that focus on women parts,that's showing them all the kinds of jwelery for human to wear.</h4></center>
        <br>
        <br>
        <center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3612.5197925628336!2d55.202796685995295!3d25.11811184107065!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f6bbec39f339d%3A0x47afe5626875154c!2z2YXZiNmEINin2YTYpdmF2KfYsdin2Ko!5e0!3m2!1sar!2ssa!4v1672158158315!5m2!1sar!2ssa" width="300" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"width="20" height="50" frameborder="0"
                    style="border:0;"
                    allowfullscreen=""
                    aria-hidden="false"
                    tabindex="0"></iframe></center>
                       <hr>
          <center><h1> Social media profile</h1></center>
        <a href="https://facebook.com">
              <center><h2> Contact us with Facebook</h2></center>
              </a>
             <center> <img src="Facebook.png" width="200" height="200"/></center>
                  
              <a href="https://Twitter.com">
                <center><h2> Contact us with Twitter</h2></center>
        <center><img src="Twitter.png"width="200" height="200"/></center>
       </a>
        <a href="https://www.instagram.com">
     <center><h2> Contact us with Instegram</h2></center>
        </a>
         <center><img src="Instgram.jpg" width="200" height="200"/></center>
        
        
        
        
        
          <footer>
           <h1> Lolia Jewelry  </h1>
            <ul style="text-align: left">
                <li><a href="homepage.php"> Home </a></li>
                <li><a href="homepage.php"> Prodects categories </a></li>
                <li><a href="About.php"> About us </a></li>
                <li><a href="contact.php"> Contact </a></li>
            
            </ul>
        </footer>
    
    </body>










</html>