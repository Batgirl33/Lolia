
<html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
    <title> 
        Lolia shope
        </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
        
        </style>
        <link rel="stylesheet" type="text/css" href="loginstyle.css" >
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        
    </head>
<body>
    
     <?php include('datab.php'); ?>
    <?php 
    
  if (isset($_POST['username'])) {
  	$email = $_POST['username'];
  	$password = $_POST['Password'];
  	$sql = "SELECT *  FROM admin WHERE Email='".$email."' AND password='".$password."'limit 1";
  	$r  = $db_link->query($sql);
      if(mysqli_num_rows($r))
      {
         header("location:Adminpage.php");
          
      }
      else{
         $msg = "<h1  style='color:red;'> Enter Correct Information </h1>";
      }
    

  }
	?>
  <section class="text">
        	<?php
  if (isset($msg)) {
  echo $msg;
  }else{
  	?>
	
  	<h1 class="text-2">Login</h1>
  	<?php
  }
      
  	 ?>


            <div class="container">
        <div class="forms">
            <div class="form login">
                <span class="title">Login</span>

                <form action=""  method="post">
                    <div class="input-field">
                        <input type="text" name="username" placeholder="Enter your email" required>
                        <i class="uil uil-envelope icon"></i>
                    </div>
                    <div class="input-field">
                        <input type="password" name="Password" class="password" placeholder="Enter your password" required>
                        <i class="uil uil-lock icon"></i>
                        <i class="uil uil-eye-slash showHidePw"></i>
                    </div>

                    <div class="checkbox-text">
                        <div class="checkbox-content">
                            <input type="checkbox" id="logCheck">
                            <label for="logCheck" class="text">Remember me</label>
                        </div>
                        
                        <a href="#" class="text">Forgot password?</a>
                    </div>

                    <div class="input-field button">
                       <input type="submit" name="submit" >
                    </div>
                </form>

                <div class="login-signup">
                        <span>
                        <br><a href="homepage.html" class="text signup-link">Back to the Home page</a>
                    </span>
                </div>
            </div>


            </div>
        </div>
    </section>
    </body>

</html>