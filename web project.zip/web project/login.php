<?php 
ob_start();
session_start();
include('datab.php');
?>
<html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
    <title> 
        Lolia shope
        </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
        
        </style>
        <link rel="stylesheet" type="text/css" href="loginstyle.css" >
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

        
        
    </head>
<body>
     
     <?php 
    if (isset($_POST['username'])) {
  	$email = $_POST['username'];
  	$password = $_POST['Password'];
  	$sql = "SELECT *  FROM customer WHERE Email='".$email."' AND Password='".$password."' limit 1" ;
     $r  = $db_link->query($sql);
        
        if($r->num_rows > 0)
        {
            $_SESSION['Email']= $email;  
            header("location:homepage.php");
            die;
            
        }
 }

  
    ?>
    <section class="text">

  
      
  	 

    
    
            <div class="container">
        <div class="forms">
            <div class="form login">
                <span class="title">Login</span>

                <form action="" method="post">
                    <div class="input-field">
                        <input type="text" name=username placeholder="Enter your email" required>
                        <i class="uil uil-envelope icon"></i>
                    </div>
                    <div class="input-field">
                        <input type="password" name="Password" class="password" placeholder="Enter your password" required>
                        <i class="uil uil-lock icon"></i>
                        <i class="uil uil-eye-slash showHidePw"></i>
                    </div>

                    <div class="checkbox-text">
                        <div class="checkbox-content">
                            <input type="checkbox" id="logCheck">
                            <label for="logCheck" class="text">Remember me</label>
                        </div>
                        
                        <a href="#" class="text">Forgot password?</a>
                    </div>

                    <div class="input-field button">
                        <input type="submit" value="Login">
                    </div>
                </form>

                <div class="login-signup">
                    <span class="text">Not a member?
                        <a href="reg.php" class="text signup-link">Registration Now</a>
                        <br><span> are you admin? </span> <a href="Admin_login.php" class="text signup-link">Admin login page</a>
                        <br><a href="homepage.php" class="text signup-link">Back to the Home page</a>
                    </span>
                </div>
            </div>

            <!-- Registration Form -->
            <div class="form signup">
                <span class="title">Registration</span>

                <form action="#">
                    <div class="input-field">
                        <input type="text" placeholder="Enter your name" required>
                        <i class="uil uil-user"></i>
                    </div>
                    <div class="input-field">
                        <input type="text" placeholder="Enter your email" required>
                        <i class="uil uil-envelope icon"></i>
                    </div>
                    <div class="input-field">
                        <input type="password" class="password" placeholder="Create a password" required>
                        <i class="uil uil-lock icon"></i>
                    </div>
                    <div class="input-field">
                        <input type="password" class="password" placeholder="Confirm a password" required>
                        <i class="uil uil-lock icon"></i>
                        <i class="uil uil-eye-slash showHidePw"></i>
                    </div>

                    <div class="checkbox-text">
                        <div class="checkbox-content">
                            <input type="checkbox" id="termCon">
                            <label for="termCon" class="text">I accepted all terms and conditions</label>
                        </div>
                    </div>

                    <div class="input-field button">
                        <input type="button" value="Signup">
                    </div>
                </form>

                <div class="login-signup">
                    <span class="text">Already a member?
                        <a href="login.php" class="text login-link">Login Now</a>
                    </span>
                </div>
            </div>
        </div>
    </div>
    </section> 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    </body>

</html>